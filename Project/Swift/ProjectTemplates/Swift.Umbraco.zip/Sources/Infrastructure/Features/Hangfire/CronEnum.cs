﻿namespace $safeprojectname$.$safeprojectname$.Hangfire
{
    public enum CronEnum
    {
        Minutely,
        Hourly,
        Daily,
        Weekly,
        Monthly,
        Yearly
    }
}
