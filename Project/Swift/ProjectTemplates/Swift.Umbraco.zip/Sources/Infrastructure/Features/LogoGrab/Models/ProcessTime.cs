﻿namespace $safeprojectname$.$safeprojectname$.LogoGrab.Models
{
    public class ProcessTime
    {
        public double Time { get; set; }
        public string Unit { get; set; }
    }
}
