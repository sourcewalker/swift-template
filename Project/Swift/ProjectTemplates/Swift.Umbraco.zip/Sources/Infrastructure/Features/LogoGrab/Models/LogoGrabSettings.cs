﻿namespace $safeprojectname$.$safeprojectname$.LogoGrab.Models
{
    public class LogoGrabSettings
    {
        public string ApiUrl { get; set; }
        public string DeveloperKey { get; set; }
    }
}
