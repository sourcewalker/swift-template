﻿namespace $safeprojectname$.$safeprojectname$.InstantWin
{
    public enum GeneratorAlgorithms
    {
        DivideAndConquer
    }
}
