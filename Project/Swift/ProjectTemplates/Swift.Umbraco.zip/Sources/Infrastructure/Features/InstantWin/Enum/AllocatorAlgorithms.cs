﻿namespace $safeprojectname$.$safeprojectname$.InstantWin
{
    public enum AllocatorAlgorithms
    {
        Blind,
        Weighted,
        Fair
    }
}
