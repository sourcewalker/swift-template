﻿namespace $safeprojectname$.DTO
{
    public enum GeneratorLimitOptions
    {
        LimitPerCampaign,
        LimitPerMonth,
        LimitPerDay,
        LimitPerHour
    }
}
