﻿using System;

namespace Swift.Umbraco.$safeprojectname$.DTO
{
    public class CampaignConfiguration
    {
        public DateTimeOffset StartDate { get; set; }

        public DateTimeOffset EndDate { get; set; }
    }
}
