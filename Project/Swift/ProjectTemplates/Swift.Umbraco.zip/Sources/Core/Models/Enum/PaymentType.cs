﻿namespace Swift.Umbraco.$safeprojectname$.Enum
{
    public enum PaymentType
    {
        CHEQUE,
        BACS_TRANSFER
    }
}
