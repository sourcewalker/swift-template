﻿namespace Swift.Umbraco.$safeprojectname$.Enum
{
    public enum Countries
    {
        UK,
        IE
    }
}
