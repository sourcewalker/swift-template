﻿namespace Swift.Umbraco.$safeprojectname$.Manager.Interfaces
{
    public interface IFailedTransactionManager
    {
    }
}
