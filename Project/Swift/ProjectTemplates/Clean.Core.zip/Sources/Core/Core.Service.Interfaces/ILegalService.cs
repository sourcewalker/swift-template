﻿using System.Threading.Tasks;

namespace $safeprojectname$
{
    public interface ILegalService
    {
        Task<string> GetPrivacyPolicyTextAsync();
    }
}
