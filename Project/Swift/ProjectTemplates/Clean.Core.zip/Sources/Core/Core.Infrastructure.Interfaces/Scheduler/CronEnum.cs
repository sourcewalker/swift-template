﻿namespace $safeprojectname$.Scheduler
{
    public enum CronEnum
    {
        Minutely,
        Hourly,
        Daily,
        Weekly,
        Monthly,
        Yearly
    }
}
