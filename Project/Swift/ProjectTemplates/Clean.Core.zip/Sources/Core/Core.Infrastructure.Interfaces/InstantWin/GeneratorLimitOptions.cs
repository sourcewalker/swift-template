﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.InstantWin
{
    public enum GeneratorLimitOptions
    {
        LimitPerCampaign,
        LimitPerMonth,
        LimitPerDay,
        LimitPerHour
    }
}
