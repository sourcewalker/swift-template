﻿namespace $safeprojectname$.CRM
{
    public interface ICrmAuthenticationProvider
    {
    }
}
