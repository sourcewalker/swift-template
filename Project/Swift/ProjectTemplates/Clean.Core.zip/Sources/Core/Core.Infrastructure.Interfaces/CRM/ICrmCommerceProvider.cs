﻿namespace $safeprojectname$.CRM
{
    public interface ICrmCommerceProvider
    {
    }
}
