export type SiteType = {
  id: string;
  culture: string;
  name: string;
  domain: string;
  createdDate: string;
  modifiedDate: string;
}
