﻿namespace $safeprojectname$.Enums
{
    public enum GeneratorAlgorithms
    {
        DivideAndConquer
    }
}
