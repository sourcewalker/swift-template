﻿using Core.Infrastructure.Interfaces.Logging;
using System;

namespace $safeprojectname$
{
    public class LoggingProvider : ILoggingProvider
    {
        public void LogError(string errorMessage, Exception ex)
        {
            
        }

        public void LogInfo(string message)
        {
            
        }

        public void LogTrace(string errorMessage, string dataString)
        {
            
        }

        public void LogWarn(string errorMessage, string dataString)
        {
            
        }
    }
}
