﻿using Newtonsoft.Json;

namespace $safeprojectname$.Ecommerce.Entities
{
    public class Shop
    {
        [JsonProperty("Id")]
        public long Id { get; set; }
    }
}
