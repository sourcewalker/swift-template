﻿namespace $safeprojectname$.Permission
{
    public class PermissionProvider
    {
    }
}
