﻿using $safeprojectname$.Models;

namespace $safeprojectname$.Interfaces
{
    public interface IRegistrationProvider
    {
        KuhmunityResponse Register();
    }
}
