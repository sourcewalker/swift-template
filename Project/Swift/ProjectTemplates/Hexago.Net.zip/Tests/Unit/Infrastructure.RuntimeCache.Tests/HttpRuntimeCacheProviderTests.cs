﻿using Infrastructure.RuntimeCache;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $safeprojectname$
{
    [TestClass]
    public class HttpRuntimeCacheProviderTests
    {

        [TestMethod()]
        public void AddTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void ContainsKeyTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetAllCacheKeysTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void PurgeTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void RemoveTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void RemoveByPrefixTest()
        {
            Assert.Fail();
        }
    }
}
