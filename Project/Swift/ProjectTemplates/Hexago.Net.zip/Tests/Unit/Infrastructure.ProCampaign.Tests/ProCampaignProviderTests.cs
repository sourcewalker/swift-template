﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $safeprojectname$
{
    [TestClass]
    public class ProCampaignProviderTests
    {
        [TestMethod]
        public void CreateTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void DeleteTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void ReadTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void UpdateTest()
        {
            Assert.Fail();
        }
    }
}