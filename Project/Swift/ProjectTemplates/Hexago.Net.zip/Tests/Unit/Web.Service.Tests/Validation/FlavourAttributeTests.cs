﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Web.Service.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Service.Validation.Tests
{
    [TestClass]
    public class FlavourAttributeTests
    {
        [TestMethod]
        public void FlavourAttributeTest()
        {
            Assert.Fail();
        }
    }
}