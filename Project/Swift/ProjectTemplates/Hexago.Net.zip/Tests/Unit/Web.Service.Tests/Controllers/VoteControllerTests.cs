﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Web.Service.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.Service.Controllers.Tests
{
    [TestClass]
    public class VoteControllerTests
    {
        [TestMethod]
        public void VoteControllerTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void VoteTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void SurveyTest()
        {
            Assert.Fail();
        }
    }
}