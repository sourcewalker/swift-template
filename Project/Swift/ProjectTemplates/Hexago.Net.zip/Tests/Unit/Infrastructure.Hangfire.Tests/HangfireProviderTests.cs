﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Infrastructure.Hangfire;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    [TestClass]
    public class HangfireProviderTests
    {
        [TestMethod]
        public void EnqueueDelayedTaskTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void EnqueueImmediateTaskTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void ScheduleRecurrentTaskTest()
        {
            Assert.Fail();
        }
    }
}