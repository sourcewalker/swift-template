﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Infrastructure.Community;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    [TestClass]
    public class CommunityProviderTests
    {
        [TestMethod]
        public void ChangePasswordTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void LoginTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void RegisterTest()
        {
            Assert.Fail();
        }
    }
}