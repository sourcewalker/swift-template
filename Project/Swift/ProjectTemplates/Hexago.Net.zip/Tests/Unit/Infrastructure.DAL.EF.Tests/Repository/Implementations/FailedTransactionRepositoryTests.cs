﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Core.DAL.Repository.Implementations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.DAL.Repository.Implementations.Tests
{
    [TestClass]
    public class FailedTransactionRepositoryTests
    {
        [TestMethod]
        public void GetAllTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void GetAllAsyncTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void GetByIdTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void GetByIdAsyncTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void GetPagedTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void GetPagedAsyncTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void UpdateTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void UpdateAsyncTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void AddTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void AddAsyncTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void DeleteTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void DeleteAsyncTest()
        {
            Assert.Fail();
        }
    }
}