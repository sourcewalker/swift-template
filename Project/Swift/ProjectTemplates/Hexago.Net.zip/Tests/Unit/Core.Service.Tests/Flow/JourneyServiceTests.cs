﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $safeprojectname$.Flow
{
    [TestClass]
    public class JourneyServiceTests
    {

        [TestMethod]
        public void ParticipateToVoteAsyncTest()
        {
            Assert.Fail();
        }
    }
}