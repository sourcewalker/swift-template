﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $safeprojectname$.Flow
{
    [TestClass]
    public class SurveyServiceTests
    {

        [TestMethod]
        public void ExtractParticipationTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void GetParticipationNumberBySiteTest()
        {
            Assert.Fail();
        }
    }
}