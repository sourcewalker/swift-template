﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $safeprojectname$.Flow
{
    [TestClass]
    public class ValidationServiceTests
    {

        [TestMethod]
        public void ValidateCaptchaTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void HasAlreadyParticipatedTest()
        {
            Assert.Fail();
        }
    }
}