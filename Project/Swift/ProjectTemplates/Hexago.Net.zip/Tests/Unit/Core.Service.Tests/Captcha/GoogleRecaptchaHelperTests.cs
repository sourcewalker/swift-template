﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Core.Service.Captcha.Tests
{
    [TestClass]
    public class GoogleRecaptchaHelperTests
    {
        [TestMethod]
        public void ValidateReCaptchaV2Test()
        {
            Assert.Fail();
        }
    }
}