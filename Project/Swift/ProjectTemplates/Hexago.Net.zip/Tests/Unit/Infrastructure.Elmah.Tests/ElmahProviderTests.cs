﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $safeprojectname$
{
    [TestClass]
    public class ElmahProviderTests
    {
        [TestMethod]
        public void LogErrorTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void LogErrorTest1()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void LogInfoTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void LogTraceTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void LogTraceTest1()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void LogWarnTest()
        {
            Assert.Fail();
        }

        [TestMethod]
        public void LogWarnTest1()
        {
            Assert.Fail();
        }
    }
}