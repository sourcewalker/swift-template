﻿namespace $safeprojectname$.Services.Models
{
    public class DataModel
    {
    }
}