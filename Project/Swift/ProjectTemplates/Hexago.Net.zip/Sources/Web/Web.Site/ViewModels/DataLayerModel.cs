﻿using System;

namespace $safeprojectname$.ViewModels
{
    public class DataLayerModel
    {
        public Guid participation_ID_head { get; set; }

        public Guid participant_ID_head { get; set; }

        public string consumer_ID_head { get; set; }

        public string selected_bar_head { get; set; }

        public string purchased_shop_head { get; set; }

        public string shortlisted_flavours_head { get; set; }

        public string country_residence_head { get; set; }

        public string prize_draw_head { get; set; }

        public string week_number_head { get; set; }

        public string first_position_head { get; set; }

        public string second_position_head { get; set; }

        public string third_position_head { get; set; }
    }
}