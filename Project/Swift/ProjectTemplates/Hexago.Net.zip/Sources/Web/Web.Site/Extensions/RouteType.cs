﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Extensions
{
    public enum RouteType
    {
        Page,
        PageAnonymous,
        Partial
    }
}