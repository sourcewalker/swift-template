﻿namespace $safeprojectname$.Status
{
    public enum ParticipationStatus
    {
        PARTICIPATION_NOT_SYNCED,
        PARTICIPATION_SYNCED_SUCCESS,
        PARTICIPATION_SYNCED_FAILED,
        PARTICIPATION_RETRY_SUCCESS,
        PARTICIPATION_RETRY_FAILED
    }
}
