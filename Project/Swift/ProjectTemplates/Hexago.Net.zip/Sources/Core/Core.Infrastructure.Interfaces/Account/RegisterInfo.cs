﻿namespace $safeprojectname$.Account
{
    public class RegisterInfo
    {
        public string Name { get; set; }
    }
}
