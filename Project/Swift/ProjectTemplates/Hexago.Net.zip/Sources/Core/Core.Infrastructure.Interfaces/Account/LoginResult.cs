﻿namespace $safeprojectname$.Account
{
    public class LoginResult
    {
        public int Code { get; set; }

        public bool Success { get; set; }

        public string Message { get; set; }
    }
}
