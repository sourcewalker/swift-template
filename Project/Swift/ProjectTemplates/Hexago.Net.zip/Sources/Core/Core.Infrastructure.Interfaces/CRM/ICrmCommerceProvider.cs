﻿namespace $safeprojectname$.Crm
{
    public interface ICrmCommerceProvider
    {
    }
}
