﻿
namespace $safeprojectname$.Crm
{
    public interface ICrmAuthenticationProvider
    {
    }
}
