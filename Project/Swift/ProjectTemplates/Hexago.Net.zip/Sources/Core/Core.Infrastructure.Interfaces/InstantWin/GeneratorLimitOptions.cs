﻿namespace $safeprojectname$.InstantWin
{
    public enum GeneratorLimitOptions
    {
        LimitPerCampaign,
        LimitPerMonth,
        LimitPerDay,
        LimitPerHour
    }
}
