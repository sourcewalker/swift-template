﻿
namespace $safeprojectname$.Models
{
    public enum Environments
    {
        Local,
        Production
    }
}
