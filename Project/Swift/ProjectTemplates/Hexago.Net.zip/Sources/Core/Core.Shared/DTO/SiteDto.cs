﻿using System;

namespace $safeprojectname$.DTO
{
    public class SiteDto : BaseDto
    {

        public string Culture { get; set; }

        public string Name { get; set; }

        public string Domain { get; set; }
    }
}
