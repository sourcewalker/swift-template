﻿namespace $safeprojectname$.Enums
{
    public enum AllocatorAlgorithms
    {
        Blind,
        Weighted,
        Fair
    }
}
