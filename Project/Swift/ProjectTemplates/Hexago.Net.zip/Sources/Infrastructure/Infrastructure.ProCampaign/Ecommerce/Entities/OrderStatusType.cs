﻿
namespace $safeprojectname$.Ecommerce.Entities
{
    public enum OrderStatusType
    {
        incomplete,
        complete_non_confirmed,
        complete_confirmed
    }
}
