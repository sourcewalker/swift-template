﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Ecommerce.Entities
{
    public enum Availability
    {
        InStock = 0,
        OutOfStock = 1,
        PreOrder = 2
    }
}
