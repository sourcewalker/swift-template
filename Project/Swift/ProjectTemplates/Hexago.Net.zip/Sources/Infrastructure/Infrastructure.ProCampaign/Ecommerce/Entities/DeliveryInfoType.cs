﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Ecommerce.Entities
{
    public enum DeliveryInfoType
    {
        ParcelService = 0,
        TransportCompany = 1,
        Email = 2,
        Download = 3
    }
}
