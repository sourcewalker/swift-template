﻿namespace $safeprojectname$.Status
{
    public struct ResponseStatus
    {
        public const string OK = "OK";
        public const string FAIL = "FAIL";
    }
}