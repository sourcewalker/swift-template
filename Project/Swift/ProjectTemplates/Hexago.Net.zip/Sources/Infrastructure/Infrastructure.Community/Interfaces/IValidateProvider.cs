﻿using $safeprojectname$.Models;

namespace $safeprojectname$.Interfaces
{
    public interface IValidateProvider
    {
        KuhmunityResponse Validate();
    }
}
